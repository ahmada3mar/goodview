<template>
    <div class="   bg-primary-500" >
<div class=" container">
        <h2 class="md:px-20 px-5 md:text-5xl text-4xl text-center font-bold font-jakarta   text-black my-20">
            Trusted by
        </h2>

            <div class="flex flex-wrap justify-around gap-10 my-16">
                <img class="sm:h-28 h-16 invert" src="~/assets/ha-eliteservice.webp" alt="www.goodview-moving.com">
                <img class="sm:h-28 h-16 invert" src="~/assets/ha-screened.webp" alt="www.goodview-moving.com">
                <img class="sm:h-28 h-16 invert" src="~/assets/ha-toprated.webp" alt="www.goodview-moving.com">
                <img class="sm:h-28 h-16" src="~/assets/bbb2.png" alt="www.goodview-moving.com">
            </div>
        </div>
    </div>
</template>