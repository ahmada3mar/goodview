<template>
    <div
        class="flex flex-col md:flex-row bg-gray-100 dark:bg-gray-900 gap-10 md:gap-5 h-auto py-5 px-4 md:px-14 items-center justify-center">
        <h2
            class="text-customPrimary-100 font-bold text-3xl md:text-5xl w-full md:w-72 border-black border-b-2 md:border-b-0 md:border-r-2 text-center p-5">
            Trusted by 
        </h2>
        <div class="flex flex-wrap justify-center gap-4">
            <img class="h-24" src="~/assets/banner1.png" alt="www.goodview-moving.com">
            <img class="h-24" src="~/assets/banner2.jpeg" alt="www.goodview-moving.com">
            <img class="h-24" src="~/assets/banner3.png" alt="www.goodview-moving.com">
            <img class="h-24" src="~/assets/banner4.png" alt="www.goodview-moving.com">
        </div>
    </div>
</template>