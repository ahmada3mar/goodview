<template>
    <div class="container mx-auto px-5">

      <!-- Main Heading Section -->
      <div class="flex flex-col my-20 md:my-36 justify-center items-center text-center">
        <h2 class="text-4xl md:text-6xl mb-5">Moving Company in USA</h2>
        <p class="text-lg md:text-xl">
          Every individual or company has considered relocation at some point or another. Why not make your move as smooth as possible and make sure that your possessions are in capable hands? Moving inside, or away from, USA needn't be stressful once you enlist the assistance of the seasoned moving professionals at GoodView Moving And Storage.
        </p>
      </div>

      <!-- First Section: A Full Range Of Moving Services -->
      <div class="flex flex-wrap gap-10 lg:gap-20 items-center py-10 md:py-20">
        <div class="img1 relative bg-primary-500 rounded-2xl p-2 w-full lg:w-1/2">
          <img class="w-full h-auto rounded-none" src="~/assets/details1.png" alt="Details Image 1 goodview">
          <div class="dot"></div>
          <div class="dot"></div>
        </div>

        <div class="flex flex-col gap-5 flex-1">
          <h2 class="text-4xl md:text-6xl mb-5">A Full Range Of Moving Services</h2>
          <p class="text-lg md:text-xl">
            <span class="text-primary-500 font-bold">GOODVIEW</span> MOVING AND STORAGE team can be hired to plan your move, organize packing, safely transport your possessions, and set you up at your new location with ease.
          </p>
          <p class="text-lg md:text-xl">
            <span class="text-primary-500 font-bold">Need storage?</span> No problem! We manage residential or commercial moves from start to finish, or provide only the services that you need. <span class="text-primary-500 font-bold">GOODVIEW</span> Moving And Storage professionals consistently adhere to the highest security standards in the business and work closely with customers to meet any requirement.
          </p>
        </div>
      </div>

      <!-- Second Section: Local or Long Distance Moves -->
      <div class="flex flex-wrap gap-10 lg:gap-20 items-center py-10 md:py-20">
        <div class="flex flex-col gap-5 flex-1">
          <h2 class="text-4xl md:text-6xl mb-5">Local or Long Distance Moves</h2>
          <p class="text-lg md:text-xl">
            Whether you are moving inside USA or outside of it, we're there to make certain all your property is transported without incident. We map out our routes to be sure that your possessions are on the road for as short a time as possible. When we wrap and package, our customers can rest assured that we always keep in mind that we need to protect any fragile items.
          </p>
        </div>

        <div class="img1 relative bg-primary-500 rounded-2xl p-2 w-full lg:w-1/2">
          <img class="w-full h-auto rounded-none" src="~/assets/details2.png" alt="Details Image goodview">
          <div class="dot"></div>
          <div class="dot"></div>
        </div>
      </div>

    </div>
  </template>

  <style scoped>
  .img1 img {
    border-radius: 15px;
  }

  .img1 {
    position: relative;
    width: 100%;
    max-width: 617px; /* Ensures proper scaling for larger screens */
  }

  </style>
