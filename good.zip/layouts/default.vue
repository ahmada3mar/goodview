<template>
    <div>
        <NavBar/>
        <slot />
        <Footer/>
    </div>
</template>