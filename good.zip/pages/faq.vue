<template>
    <div>

    <div class="flex flex-col h-full">
        <Banner background="/assets/faq.webp" class="h-[20rem] md:h-[30rem]" title="Tips" text="Moving can be a stressful and time- consuming process, but with some planning
and preparation, it can also be a smooth and hassle-free experience. Here are
some tips and advice from GoodView, to
help you with your move." />


    </div>

    <div class=" bg-primary-500 w-full p-3 md:p-10   rounded-none">
            <div class="border-b-2 border-black px-32 py-10">
    <h2 class="font-bold">Do you provide moving services in USA, and surrounding areas?</h2>
    <p>Yes, we offer moving services within USA, and nearby regions, ensuring a smooth and hassle-free experience.</p>
</div>

<div class="border-b-2 border-black px-32 py-10">
    <h2 class="font-bold">How far in advance should I book my move?</h2>
    <p>We recommend booking your move at least 2-4 weeks in advance to secure your preferred date and time.</p>
</div>

<div class="border-b-2 border-black px-32 py-10">
    <h2 class="font-bold">Do you offer packing services?</h2>
    <p>Yes, we provide professional packing and unpacking services to ensure your items are safely prepared for the move.</p>
</div>

<div class="border-b-2 border-black px-32 py-10">
    <h2 class="font-bold">Are my belongings insured during the move?</h2>
    <p>Yes, we offer insurance options to protect your belongings in case of unexpected incidents during the move.</p>
</div>

<div class="border-b-2 border-black px-32 py-10">
    <h2 class="font-bold">Can you handle specialty items like pianos or antiques?</h2>
    <p>Absolutely! We have the expertise and equipment to safely move specialty items, including pianos, antiques, and art pieces.</p>
</div>

<div class="border-b-2 border-black px-32 py-10">
    <h2 class="font-bold">Do you provide moving supplies like boxes and tape?</h2>
    <p>Yes, we offer high-quality packing materials, including boxes, tape, and bubble wrap, to ensure the safety of your items.</p>
</div>

<div class="border-b-2 border-black px-32 py-10">
    <h2 class="font-bold">How are moving costs determined?</h2>
    <p>Our moving costs are based on factors such as distance, the size of your move, and additional services like packing or storage.</p>
</div>

<div class="border-b-2 border-black px-32 py-10">
    <h2 class="font-bold">Do you offer storage options?</h2>
    <p>Yes, we provide secure short-term and long-term storage solutions to accommodate your needs.</p>
</div>

<div class="border-b-2 border-black px-32 py-10">
    <h2 class="font-bold">Can I change my moving date after booking?</h2>
    <p>We understand that plans can change and will do our best to accommodate rescheduling requests with sufficient notice.</p>
</div>

<div class="border-b-2 border-black px-32 py-10">
    <h2 class="font-bold">What safety measures do you take for my belongings?</h2>
    <p>We use professional-grade equipment, secure packing methods, and experienced movers to ensure the safety of your items throughout the process.</p>
</div>



    </div>
</div>

</template>

<script setup>

const items = [{
    label: 'FAQs',
    icon: 'i-carbon-delivery-truck',
    slot: 'moving'
}
]

</script>